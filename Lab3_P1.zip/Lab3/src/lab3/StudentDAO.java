/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;


import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author mac
 */
public class StudentDAO {
    
    public static void loadDataToJTable(DefaultTableModel model)
    {
        
        for(int i=0;i<6;i++)
        {
            //dua du lieu vao sinh vien
        Student s=new Student();
        s.HoTen = "Nguyen Van A";
        s.Diem=9.5;
        s.Nganh="TKW";
        s.HocLuc=s.getHocLuc();
        s.Thuong = s.isBonus();
        //Dua du lieu vao dong
            Vector datarow = new Vector();
            datarow.add(s.HoTen);
            datarow.add(s.Diem);
            datarow.add(s.Nganh);
            datarow.add(s.HocLuc);
            datarow.add(s.Thuong);
            //dua dong vao Jtable
            model.addRow(datarow);
                    
            
        }
      
        
    }
    
    public static void loadDataByList(DefaultTableModel model,JTable jtable)
    {
        List<Student> list = new ArrayList<>();
        
        list.add(new Student("Nguyen Van A",8.6));
        list.add(new Student("Nguyen Van A",8.5));
        list.add(new Student("Nguyen Van A",7.6));
        list.add(new Student("Nguyen Van A",6.6));
        list.add(new Student("Nguyen Van A",4.6));
        
        
        model = (DefaultTableModel)jtable.getModel();
        model.setRowCount(0);
        for(Student sv: list)
        {
            model.addRow(new Object[]{sv.HoTen,sv.Diem,sv.HocLuc,"TKW",sv.Thuong});
        }
       
        
    }
    
    public static void loadDataOnCombobox(JComboBox cbx)
    {
         List<Student> list = new ArrayList<>();
        
        list.add(new Student("Nguyen Van A",8.6));
        list.add(new Student("Tran Van A",8.5));
        list.add(new Student("To Van C",7.6));
        list.add(new Student("Lo Van D",6.6));
        list.add(new Student("Le Van E",4.6));
        
        for(Student sv: list)
        {
            cbx.addItem(sv.HoTen);
        }
    }
    
}
