/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3;

/**
 *
 * @author mac
 */
public class Student {
    public String HoTen;
    public double Diem;
    public String HocLuc;
    public String Nganh;
    public Boolean Thuong;
    
    public Student(){}

    public Student(String HoTen, double Diem) {
        this.HoTen = HoTen;
        this.Diem = Diem;
    }
    

    public Student(String HoTen, double Diem, String HocLuc, String Nganh, Boolean Thuong) {
        this.HoTen = HoTen;
        this.Diem = Diem;
        this.HocLuc = HocLuc;
        this.Nganh = Nganh;
        this.Thuong = Thuong;
    }
    
      public boolean isBonus()
    {
        return this.Diem>=7.5;
    }

    
    public String getMark()
    {
        String ketqua="";
        
        if(Diem<3 && Diem>=0)
        {
            ketqua = "kem";
        }
        else if(Diem<5){
            ketqua = "yeu";}
        else if(Diem<6.5)
            ketqua = "Trung binh";
        else if(Diem<7.5)
            ketqua = "kha";
        else if(Diem<9)
            ketqua="gioi";
        else if(Diem<=10)
            ketqua = "xuat sac";
        else ketqua="Khong co xep loai nay";
                    
        
        
        return ketqua;
        
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public double getDiem() {
        return Diem;
    }

    public void setDiem(double Diem) {
        this.Diem = Diem;
    }

    public String getHocLuc() {
        return HocLuc;
    }

    public void setHocLuc(String HocLuc) {
        this.HocLuc = HocLuc;
    }

    public String getNganh() {
        return Nganh;
    }

    public void setNganh(String Nganh) {
        this.Nganh = Nganh;
    }

    public Boolean getThuong() {
        return Thuong;
    }

    public void setThuong(Boolean Thuong) {
        this.Thuong = Thuong;
    }
    
    
    
}
